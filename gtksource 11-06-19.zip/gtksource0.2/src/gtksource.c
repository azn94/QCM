#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <unistd.h>
#include <gmodule.h>
#include <string.h>

#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xmlreader.h>
#include <libxml/xmlmemory.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/xmlwriter.h>

#define NBR_LVL_F 10
#define NBR_LVL_M 10
#define L_FENETRE 700
#define H_FENETRE 450
#define NBR_PAYS 193

typedef struct {
  GtkWidget *wid;
  char *yes;
  char *nom_utilisateur;
  char *nom_mauvaise;
  int nbr_matrice;

} stru;

typedef struct {
  int nombre;
  int nombre_br;
  char *nom;

} nom_nombre;

typedef struct {
	GtkWidget *wid;
  char *nom1;
  char *nom2;
} nom_nom_nombre;

typedef struct {
  char *nom1;
} nom_struct;

enum {
  COLUMN = 0,
  NUM_COLS
};

void changer_matrice(char* nom_fichier,char* adresse){
	xmlInitParser();
	LIBXML_TEST_VERSION
	xmlDoc *doc = xmlParseFile(nom_fichier);
	xmlXPathContext *xpathCtx = xmlXPathNewContext( doc );
	xmlXPathObject * xpathObj =xmlXPathEvalExpression( (xmlChar*)adresse, xpathCtx );
	int nbr_matrice= xmlXPathNodeSetGetLength(xpathObj->nodesetval);
	xmlNode *node = xpathObj->nodesetval->nodeTab[nbr_matrice-1];
	xmlNodeSetContent(node, "1");
	xmlSaveFormatFileEnc( nom_fichier, doc, "utf-8", 1 );
	xmlXPathFreeObject( xpathObj );
	xmlXPathFreeContext( xpathCtx );
	xmlFreeDoc( doc );
	xmlCleanupParser();
}

void bonne_reponse(GtkWidget *widget, gpointer haribo) {
	GtkWidget *dialog;
	stru *london=malloc(sizeof(*london));
	london=haribo;

	printf("\n---------\nbonne réponse l'adresse à remplir est : %s/%s/%s\n---------\n",london->nom_utilisateur,london->yes,london->yes);
	char nom_fichier[5000],adresse[5000];
	g_snprintf(adresse,5000,"/%s/matrice/%s/%s",london->nom_utilisateur,london->yes,london->yes);
	g_snprintf(nom_fichier,5000,"%s.xml",london->nom_utilisateur);
	changer_matrice(nom_fichier,adresse);

   dialog = gtk_message_dialog_new(GTK_WINDOW(london->wid),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_QUESTION,GTK_BUTTONS_OK,"Bonne réponse");
   gtk_dialog_run(GTK_DIALOG(dialog));
   gtk_widget_destroy(dialog);

   free(haribo);

}

void mauvaise_reponse(GtkWidget *widget, gpointer haribo) {
	GtkWidget *dialog;
	stru *london=malloc(sizeof(*london));
	london=haribo;

	printf("\n---------\nmauvaise réponse l'adresse à remplir est : %s/%s/%s\n---------\n",london->nom_utilisateur,london->yes,london->nom_mauvaise);


	char nom_fichier[500],adresse[500];
	g_snprintf(adresse,500,"/%s/matrice/%s/%s",london->nom_utilisateur,london->yes,london->nom_mauvaise);
	g_snprintf(nom_fichier,500,"%s.xml",london->nom_utilisateur);
	changer_matrice(nom_fichier,adresse);

	char Madrid[500];
	g_snprintf(Madrid,500,"mauvaise réponse, c'était : %s",london->yes);
	dialog = gtk_message_dialog_new(GTK_WINDOW(london->wid),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_QUESTION,GTK_BUTTONS_OK, Madrid);
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
	free(haribo);

}

void Fin_du_jeu(GtkWidget *widget, gpointer window) {
	GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_QUESTION,GTK_BUTTONS_OK,"\n\n\n\n\t\tFIN DU JEU\t\t\n\n\n\n");
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

const  char* NomPaysAleatoire (){
	FILE *f=fopen("listepays.txt","r");
	if(f==NULL){
		fprintf(stderr,"problème d'ouverture du fichier listepays \n ");
		return NULL;
	}
	static char buffer[500];
	int i=rand()%NBR_PAYS;
	int j=0;
	while(fscanf(f,"%s",buffer)&& j<i){
		j++;
	}
	printf("l'aleatoire donne : num %d -> %s\n",i,buffer);
	fclose(f);
	return buffer;

}

const  char* getPaysContinant(int c,int r){
	FILE *f;
	switch(c){
	case 0:
		f=fopen("listepaysAfrique.txt","r");
		break;
	case 1:
		f=fopen("listepaysAmerique.txt","r");
		break;
	case 2:
		f=fopen("listepaysAsie.txt","r");
		break;
	case 3:
		f=fopen("listepaysEurope.txt","r");
		break;
	case 4:
		f=fopen("listepaysOceanie.txt","r");
		break;
	}
	if(f==NULL){
		fprintf(stderr,"problème d'ouverture du fichier listepays \n ");
		return NULL;
	}
	static char buffer[100];
	int j=0;
	while(fscanf(f,"%s",buffer)&& j<r){
		j++;
	}
	fclose(f);
	return buffer;

}

const  char* getPays (int r){
	FILE *f=fopen("listepays.txt","r");
	if(f==NULL){
		fprintf(stderr,"problème d'ouverture du fichier listepays \n ");
		return NULL;
	}
	static char buffer[100];
	int j=0;
	if(fgets(buffer,100,f)==NULL)
			return NULL;
	while(fscanf(f,"%s",buffer)&& j<r){
		j++;
	}
	fclose(f);
	return buffer;

}

void fonction_facile(GtkWidget *table99, gpointer user_data){
	GtkWidget *button,*window,*table;

	int i=rand()%3,k;
	char buffer[500]="";
	char s0[500],s1[500],s2[500];
	char *tab_button[3]={strcpy(s0,NomPaysAleatoire()),strcpy(s1,NomPaysAleatoire()),strcpy(s2,NomPaysAleatoire())};
	g_snprintf(buffer,500,"drapeau/%s.png",tab_button[0]);

	printf("\nfonction facile tableau de bouton :%s-%s-%s\n",tab_button[0],tab_button[1],tab_button[2]);

	table = gtk_table_new (6, 3, TRUE);
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window), "QCM drapeau-facile");
	gtk_window_set_default_size (GTK_WINDOW (window), L_FENETRE, H_FENETRE);
	gtk_container_set_border_width (GTK_CONTAINER (window), 100);
	gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER_ALWAYS);

	gtk_table_set_col_spacings(GTK_TABLE(table), 20);
	gtk_container_add (GTK_CONTAINER (window), table);

	button = gtk_image_new_from_file(buffer);
	gtk_table_attach_defaults (GTK_TABLE (table), button, 0, 3, 0, 3);

	nom_nombre *london=malloc(sizeof(*london));
	london->nom=malloc(sizeof(char*)*100);
	london=user_data;
	london->nombre++;

	int nbr_niveau_restant=london->nombre;

	stru *haribo=malloc(sizeof(*haribo));
	haribo->yes=malloc(sizeof(char*)*100);
	haribo->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo->yes,tab_button[0]);
	strcpy(haribo->nom_utilisateur,london->nom);
	haribo->wid=window;

	stru *haribo2=malloc(sizeof(*haribo2));
	haribo2->yes=malloc(sizeof(char*)*100);
	haribo2->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo2->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo2->yes,tab_button[0]);
	strcpy(haribo2->nom_utilisateur,london->nom);
	haribo2->wid=window;

	stru *haribo3=malloc(sizeof(*haribo3));
	haribo3->yes=malloc(sizeof(char*)*100);
	haribo3->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo3->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo3->yes,tab_button[0]);
	strcpy(haribo3->nom_utilisateur,london->nom);
	haribo3->wid=window;

	for(k=0;k<3;k++){
		while(tab_button[i]==0){
				i=rand()%3;
			}
		button = gtk_button_new_with_label(tab_button[i]);

		gtk_table_attach_defaults (GTK_TABLE (table), button, k,k+1, 4, 5);
		if(i==0){
			if(k==0)
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo);
			if(k==1)
					g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo2);
			if(k==2)
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo3);
		}else{
			if(k==0){
				strcpy(haribo->nom_mauvaise,tab_button[i]);
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo);
			}
			if(k==1){
				strcpy(haribo2->nom_mauvaise,tab_button[i]);
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo2);
			}
			if(k==2){
				strcpy(haribo3->nom_mauvaise,tab_button[i]);
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo3);
			}
		}
		tab_button[i]=0;
		if (nbr_niveau_restant<NBR_LVL_F)
			g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( fonction_facile), london);
		else{
			g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( Fin_du_jeu), window);
			london->nombre=0;
			}
		g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window);
	}
	gtk_widget_show_all(GTK_WIDGET(window));

}

void fonction_moyen2(GtkWidget *table99,gpointer user_data){
	GtkWidget *window,*table;
	GtkWidget *button;
	int i=rand()%6,k;
	char buffer[500]="";
	char s0[500],s1[500],s2[500],s3[500],s4[500],s5[500];
	char *tab_button[6]={strcpy(s0,NomPaysAleatoire()),strcpy(s1,NomPaysAleatoire()),strcpy(s2,NomPaysAleatoire()),strcpy(s3,NomPaysAleatoire()),strcpy(s4,NomPaysAleatoire()),strcpy(s5,NomPaysAleatoire())};
	g_snprintf(buffer,500,"drapeau/%s.png",tab_button[0]);

	printf("\nfonction facile tableau de bouton :%s  %s  %s  %s  %s  %s\n",tab_button[0],tab_button[1],tab_button[2],tab_button[3],tab_button[4],tab_button[5]);

	table = gtk_table_new (6, 3, TRUE);
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window), "QCM drapeau-medium");
	gtk_window_set_default_size (GTK_WINDOW (window), L_FENETRE, H_FENETRE);
	gtk_container_set_border_width (GTK_CONTAINER (window), 100);
	gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER_ALWAYS);

	gtk_table_set_col_spacings(GTK_TABLE(table), 20);
	gtk_table_set_row_spacings(GTK_TABLE(table), 20);
	gtk_container_add (GTK_CONTAINER (window), table);


	button = gtk_image_new_from_file(buffer);
	gtk_table_attach_defaults (GTK_TABLE (table), button, 0, 3, 0, 3);

	nom_nombre *london=malloc(sizeof(*london));
	london->nom=malloc(sizeof(char*)*100);
	london=user_data;
	london->nombre++;
	int nbr_niveau_restant=london->nombre;

	stru *haribo=malloc(sizeof(*haribo));
	haribo->yes=malloc(sizeof(char*)*100);
	haribo->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo->yes,tab_button[0]);
	strcpy(haribo->nom_utilisateur,london->nom);
	haribo->wid=window;

	stru *haribo2=malloc(sizeof(*haribo2));
	haribo2->yes=malloc(sizeof(char*)*100);
	haribo2->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo2->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo2->yes,tab_button[0]);
	strcpy(haribo2->nom_utilisateur,london->nom);
	haribo2->wid=window;

	stru *haribo3=malloc(sizeof(*haribo3));
	haribo3->yes=malloc(sizeof(char*)*100);
	haribo3->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo3->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo3->yes,tab_button[0]);
	strcpy(haribo3->nom_utilisateur,london->nom);
	haribo3->wid=window;

	stru *haribo4=malloc(sizeof(*haribo4));
	haribo4->yes=malloc(sizeof(char*)*100);
	haribo4->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo4->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo4->yes,tab_button[0]);
	strcpy(haribo4->nom_utilisateur,london->nom);
	haribo4->wid=window;

	stru *haribo5=malloc(sizeof(*haribo5));
	haribo5->yes=malloc(sizeof(char*)*100);
	haribo5->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo5->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo5->yes,tab_button[0]);
	strcpy(haribo5->nom_utilisateur,london->nom);
	haribo5->wid=window;

	stru *haribo6=malloc(sizeof(*haribo6));
	haribo6->yes=malloc(sizeof(char*)*100);
	haribo6->nom_utilisateur=malloc(sizeof(char*)*100);
	haribo6->nom_mauvaise=malloc(sizeof(char*)*100);
	strcpy(haribo6->yes,tab_button[0]);
	strcpy(haribo6->nom_utilisateur,london->nom);
	haribo6->wid=window;

	for(k=0;k<3;k++){
		while(tab_button[i]==0){
			i=rand()%6;
		}
		button = gtk_button_new_with_label(tab_button[i]);
		gtk_table_attach_defaults (GTK_TABLE (table), button, k,k+1, 4, 5);
		if(i==0){
			if(k==0)
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo);
			if(k==1)
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo2);
			if(k==2)
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo3);
		}else{
			if(k==0){
				strcpy(haribo->nom_mauvaise,tab_button[i]);
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo);
			}
			if(k==1){
				strcpy(haribo2->nom_mauvaise,tab_button[i]);
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo2);
			}
			if(k==2){
				strcpy(haribo3->nom_mauvaise,tab_button[i]);
				g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo3);
			}
		}
		tab_button[i]=0;
		if (nbr_niveau_restant<NBR_LVL_M)
			g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( fonction_moyen2), london);
		else{
			g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( Fin_du_jeu), window);
			london->nombre=0;
		}
		g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window);
	}

	while(tab_button[i]==0){
		i=rand()%6;
	}
	button = gtk_button_new_with_label(tab_button[i]);

	gtk_table_attach_defaults (GTK_TABLE (table), button, 0,0+1, 5, 6);
	if(i==0){
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo4);
	}else{
		strcpy(haribo4->nom_mauvaise,tab_button[i]);
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo4);
	}
	tab_button[i]=0;
	if (nbr_niveau_restant<NBR_LVL_M)
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( fonction_moyen2), london);
	else{
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( Fin_du_jeu), window);
		london->nombre=0;
	}
	g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window);
	//-------------------------------------------------------------------------------------------------------

	while(tab_button[i]==0){
		i=rand()%6;
	}
	button = gtk_button_new_with_label(tab_button[i]);

	gtk_table_attach_defaults (GTK_TABLE (table), button, 1,1+1, 5, 6);
	if(i==0){
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo5);
	}else{
		strcpy(haribo5->nom_mauvaise,tab_button[i]);
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo5);
	}
	tab_button[i]=0;
	if (nbr_niveau_restant<NBR_LVL_M)
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( fonction_moyen2), london);
	else{
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( Fin_du_jeu), window);
		london->nombre=0;
	}
	g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window);
	//-------------------------------------------------------------------------------------------------------

	while(tab_button[i]==0){
		i=rand()%6;
	}
	button = gtk_button_new_with_label(tab_button[i]);

	gtk_table_attach_defaults (GTK_TABLE (table), button, 2,2+1, 5, 6);
	if(i==0){
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(bonne_reponse),  haribo6);
	}else{
		strcpy(haribo6->nom_mauvaise,tab_button[i]);
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(mauvaise_reponse),  haribo6);
	}
	tab_button[i]=0;
	if (nbr_niveau_restant<NBR_LVL_M)
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( fonction_moyen2), london);
	else{
		g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK( Fin_du_jeu), window);
		london->nombre=0;
	}
	g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window);

	gtk_widget_show_all(GTK_WIDGET(window));
}

void xml(GtkWidget *table99,gpointer user_data){
	gchar buff[1024];
	xmlTextReaderPtr reader;
	char buff2[4000];
	gchar nom[1024];
	gchar nom2[1024];
	g_snprintf(nom,1024,"%s",(char*)user_data);
	g_snprintf(buff,1024,"%s.xml",nom);

	printf("\nfonction xml \nle pseudo entré est: %s \n-------",nom);

	reader = xmlReaderForFile(buff, NULL, 0);
	if(reader != NULL){
		xmlKeepBlanksDefault(0);
		fprintf(stderr, "le fichier existe deja ");
		xmlDoc *doc = xmlParseFile(buff);
		xmlNodePtr  node_matrice = NULL, node = NULL, node1 = NULL;
		xmlXPathContext *xpathCtx = xmlXPathNewContext( doc );

		g_snprintf(nom2,1024,"/%s",nom);

		xmlXPathObject * xpathObj =xmlXPathEvalExpression((xmlChar*)nom2, xpathCtx );
		xmlNode *root_node = xpathObj->nodesetval->nodeTab[0];
		int i, j;
		LIBXML_TEST_VERSION;
		// xmlDocSetRootElement(doc, root_node);

		node_matrice = xmlNewChild(root_node, NULL, BAD_CAST "matrice", NULL);
		for (i = 0; i < NBR_PAYS; i++) {
			sprintf(buff2, getPays(i), i);
			node = xmlNewChild(node_matrice, NULL, BAD_CAST buff2, NULL);
			for (j = 0; j < NBR_PAYS; j++) {
				sprintf(buff2, getPays(j), j);
				node1 = xmlNewChild(node, NULL, BAD_CAST buff2, "0");
			}
		}
		xmlSaveFormatFileEnc( buff, doc, "utf-8", 1 );
		xmlFreeDoc(doc);
		xmlCleanupParser();
	}

	xmlDocPtr doc = NULL;
	xmlNodePtr root_node = NULL, node_matrice = NULL, node = NULL, node1 = NULL;
	int i, j;
	xmlKeepBlanksDefault(0);
	doc = xmlNewDoc(BAD_CAST "1.0");
	root_node = xmlNewNode(NULL, BAD_CAST nom);

	xmlDocSetRootElement(doc, root_node);
	node_matrice = xmlNewChild(root_node, NULL, BAD_CAST "matrice", NULL);
	for (i = 0; i < NBR_PAYS; i++) {
		sprintf(buff2, getPays(i), i);
		node = xmlNewChild(node_matrice, NULL, BAD_CAST buff2, NULL);
		for (j = 0; j < NBR_PAYS; j++) {
			sprintf(buff2, getPays(j), j);
			node1 = xmlNewChild(node, NULL, BAD_CAST buff2, "0");
		}
	}
	xmlSaveFormatFileEnc( buff, doc, "utf-8", 1 );
	xmlFreeDoc(doc);
	xmlCleanupParser();
}


void Choix_niveaux(GtkWidget *table,gpointer user_data){
	GtkWidget *window0, *table0, *layout, *image;
	GtkWidget *button, *button1, *button2;

	nom_nombre *tagada=malloc(sizeof(*tagada));
	tagada->nom=malloc(sizeof(char*)*100);
	strcpy(tagada->nom,user_data);
	//tagada->nombre=0;

	printf("choix niveau\nle pseudo entré est: %s\n-------\n",(char*)(tagada->nom));

	window0 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window0), "QCM drapeau-choix de la difficulté");
	gtk_window_set_default_size (GTK_WINDOW (window0), L_FENETRE, H_FENETRE);
	gtk_container_set_border_width (GTK_CONTAINER (window0), 5);
	gtk_window_set_position(GTK_WINDOW(window0), GTK_WIN_POS_CENTER_ALWAYS);

	layout = gtk_layout_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER (window0), layout);

	image = gtk_image_new_from_file("onu resize.png");
	gtk_layout_put(GTK_LAYOUT(layout), image, 0, 0);

	table0 = gtk_table_new (7, 6, TRUE);
	gtk_table_set_row_spacings(GTK_TABLE(table0), 50);
	gtk_table_set_col_spacings(GTK_TABLE(table0), 20);

	button = gtk_button_new_with_label ("niveau facile");
	gtk_table_attach_defaults (GTK_TABLE (table0), button , 2, 3, 1, 2);
	g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(fonction_facile), tagada);
	g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(xml), tagada->nom);

	button1 = gtk_button_new_with_label ("niveau moyen");
	gtk_table_attach_defaults (GTK_TABLE (table0), button1, 2, 3, 2, 3);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(fonction_moyen2), tagada);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(xml), tagada->nom);

	button2 = gtk_button_new_with_label ("niveau difficile");
	gtk_table_attach_defaults (GTK_TABLE (table0), button2, 2, 3, 3, 4);
	g_signal_connect(G_OBJECT(button2), "clicked",G_CALLBACK(xml), tagada->nom);

	gtk_container_add (GTK_CONTAINER (layout), table0);
	gtk_window_set_resizable (GTK_WINDOW(window0), FALSE);
	gtk_widget_set_size_request (window0, L_FENETRE, H_FENETRE);
	gtk_widget_show_all(GTK_WIDGET(window0));

}

void Afficher_Statistique(char* name){
	GtkWidget *button,*window,*table,*label1;
	char buffer[500]="";
	char buffer2[500]="";
	g_snprintf(buffer,500,"drapeau/%s.png",name);
	g_snprintf(buffer2,500,"\t%s\n votre taux d'erreur est :\n \t0%c",name,'%');

	table = gtk_table_new (5, 3, TRUE);
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window), "QCM drapeau-facile");
	gtk_window_set_default_size (GTK_WINDOW (window), L_FENETRE, H_FENETRE);
	gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER_ALWAYS);

	//gtk_table_set_col_spacings(GTK_TABLE(table), 20);
	gtk_container_add (GTK_CONTAINER (window), table);

	button = gtk_image_new_from_file(buffer);
	gtk_table_attach_defaults (GTK_TABLE (table), button, 0, 3, 0, 2);
	label1 = gtk_label_new(buffer2);
	gtk_table_attach_defaults (GTK_TABLE (table), label1, 0, 3, 2, 3);
	gtk_widget_show_all(GTK_WIDGET(window));

}

GtkTreeModel *create_and_fill_model(void) {
	GtkTreeStore *treestore;
	GtkTreeIter toplevel, child;

	treestore = gtk_tree_store_new(NUM_COLS,G_TYPE_STRING);
	int i;

	gtk_tree_store_append(treestore, &toplevel, NULL);
	gtk_tree_store_set(treestore, &toplevel, COLUMN, "Afrique", -1);
	for(i=0;i<55;i++){
		gtk_tree_store_append(treestore, &child, &toplevel);
		gtk_tree_store_set(treestore, &child, COLUMN, getPaysContinant(0,i), -1);
	}

	gtk_tree_store_append(treestore, &toplevel, NULL);
	gtk_tree_store_set(treestore, &toplevel,COLUMN, "Amerique",-1);
	for(i=0;i<32;i++){
		gtk_tree_store_append(treestore, &child, &toplevel);
		gtk_tree_store_set(treestore, &child,COLUMN, getPaysContinant(1,i),-1);
	}

	gtk_tree_store_append(treestore, &toplevel, NULL);
	gtk_tree_store_set(treestore, &toplevel,COLUMN, "Asie",-1);
	for(i=0;i<44;i++){
		gtk_tree_store_append(treestore, &child, &toplevel);
		gtk_tree_store_set(treestore, &child,COLUMN, getPaysContinant(2,i),-1);
	}

	gtk_tree_store_append(treestore, &toplevel, NULL);
	gtk_tree_store_set(treestore, &toplevel, COLUMN, "Europe",-1);
	for(i=0;i<45;i++){
		gtk_tree_store_append(treestore, &child, &toplevel);
		gtk_tree_store_set(treestore, &child,COLUMN, getPaysContinant(3,i), -1);
	}

	gtk_tree_store_append(treestore, &toplevel, NULL);
	gtk_tree_store_set(treestore, &toplevel,COLUMN, "Oceanie",-1);
	for(i=0;i<12;i++){
		gtk_tree_store_append(treestore, &child, &toplevel);
		gtk_tree_store_set(treestore, &child,COLUMN, getPaysContinant(4,i), -1);
	}

	return GTK_TREE_MODEL(treestore);

}

void DoubleClick (GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn  *col,gpointer userdata){
	GtkTreeModel *model;
	GtkTreeIter   iter;

	model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path)){
		gchar *name;
		gtk_tree_model_get(model, &iter, 0, &name, -1);
		Afficher_Statistique(name);
		g_free(name);
	}

}

GtkWidget *create_view_and_model() {
	GtkTreeViewColumn *col;
	GtkCellRenderer *renderer;
	GtkWidget *view;
	GtkTreeModel *model;

	view = gtk_tree_view_new();
	col = gtk_tree_view_column_new();
	gtk_tree_view_column_set_title(col, "Pays");
	gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

	renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(col, renderer, TRUE);
	gtk_tree_view_column_add_attribute(col, renderer,"text", COLUMN);

	model = create_and_fill_model();
	gtk_tree_view_set_model(GTK_TREE_VIEW(view), model);
	g_object_unref(model);

	g_signal_connect(view, "row-activated", (GCallback) DoubleClick, NULL);
	return view;

}

void Statistique(GtkWidget *table,gpointer user_data){
	GtkWidget *window, *view;
	GtkWidget *scrolled_window, *hbox;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
	gtk_window_set_title(GTK_WINDOW(window), "Statistique ");
	gtk_window_set_default_size (GTK_WINDOW (window), L_FENETRE, H_FENETRE);

	view = create_view_and_model();
	scrolled_window = gtk_scrolled_window_new (NULL, NULL);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window), GTK_POLICY_ALWAYS, GTK_POLICY_NEVER);
	gtk_container_add (GTK_CONTAINER(scrolled_window), view);

	hbox = gtk_hbox_new(FALSE, 0);
	gtk_container_add (GTK_CONTAINER (hbox), scrolled_window);
	gtk_container_add (GTK_CONTAINER (window), hbox);

	gtk_widget_set_size_request (window, L_FENETRE, H_FENETRE);
	gtk_widget_show_all(window);

}

void Apropos(GtkWidget *widget, gpointer data) {
	GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file("battery.png", NULL);
	GtkWidget *dialog = gtk_about_dialog_new();

	gtk_about_dialog_set_version(GTK_ABOUT_DIALOG(dialog), "4.0");
	gtk_about_dialog_set_copyright(GTK_ABOUT_DIALOG(dialog),"Youssef KADHI");
	gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(dialog),"apprendre les drapeaux du monde ");
	gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(dialog),"https://github.com/Yurof/QCM");
	gtk_about_dialog_set_logo(GTK_ABOUT_DIALOG(dialog), pixbuf);
	g_object_unref(pixbuf), pixbuf = NULL;
	gtk_dialog_run(GTK_DIALOG (dialog));
	gtk_widget_destroy(dialog);

}

void Menu_principal(GtkWidget *table,gpointer user_data){
	GtkWidget *window0, *table0, *layout, *image;
	GtkWidget *button, *button1, *button2;

	printf("Menu_principal\nle pseudo entré est: %s\n-------\n",gtk_entry_get_text(GTK_ENTRY(user_data)));

	nom_struct *dragibus=malloc(sizeof(*dragibus));
	dragibus->nom1=malloc(sizeof(char*)*100);
	strcpy(dragibus->nom1,gtk_entry_get_text(user_data));

	window0 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window0), "QCM Menu principal");
	gtk_window_set_default_size (GTK_WINDOW (window0), L_FENETRE, H_FENETRE);
	gtk_container_set_border_width (GTK_CONTAINER (window0), 5);
	gtk_window_set_position(GTK_WINDOW(window0), GTK_WIN_POS_CENTER_ALWAYS);

	layout = gtk_layout_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER (window0), layout);

	image = gtk_image_new_from_file("onu resize.png");
	gtk_layout_put(GTK_LAYOUT(layout), image, 0, 0);

	table0 = gtk_table_new (7, 5, TRUE);
	gtk_table_set_row_spacings(GTK_TABLE(table0), 50);
	gtk_table_set_col_spacings(GTK_TABLE(table0), 20);

	button = gtk_button_new_with_label ("Jouer");
	gtk_table_attach_defaults (GTK_TABLE (table0), button,2, 3, 1, 2);
	g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(Choix_niveaux),dragibus->nom1);
	g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window0);

	button1 = gtk_button_new_with_label ("  statistique   ");
	gtk_table_attach_defaults (GTK_TABLE (table0), button1,  2, 3, 2, 3);
	g_signal_connect(G_OBJECT(button1),"clicked",G_CALLBACK(Statistique),NULL);

	button2 = gtk_button_new_with_label ("  A propos ");
	gtk_table_attach_defaults (GTK_TABLE (table0), button2,  2, 3, 3, 4);
	g_signal_connect(G_OBJECT(button2),"clicked",G_CALLBACK(Apropos),NULL);

	gtk_container_add (GTK_CONTAINER (layout), table0);
	gtk_window_set_resizable (GTK_WINDOW(window0), FALSE);
	gtk_widget_set_size_request (window0, L_FENETRE, H_FENETRE);
	gtk_widget_show_all(GTK_WIDGET(window0));
	free(dragibus);
}

int main (int argc,char *argv[]){
	GtkWidget *window0, *entry, *button, *label1;
	GtkWidget *image,*layout;

	srand(time(NULL));
	gtk_init (&argc, &argv);

	window0 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window0), "QCM entrez votre nom");
	gtk_window_set_default_size (GTK_WINDOW (window0), L_FENETRE, H_FENETRE);
	gtk_container_set_border_width (GTK_CONTAINER (window0), 5);
	gtk_window_set_position(GTK_WINDOW(window0), GTK_WIN_POS_CENTER_ALWAYS);

	layout = gtk_layout_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER (window0), layout);
	gtk_widget_show(layout);

	image = gtk_image_new_from_file("onu resize.png");
	gtk_layout_put(GTK_LAYOUT(layout), image, 0, 0);

	label1 = gtk_label_new(" Entrez votre nom svp :");
	gtk_layout_put(GTK_LAYOUT(layout), label1, 270, 50);
	gtk_widget_set_size_request(label1, 80, 35);

	entry=gtk_entry_new();
	gtk_layout_put(GTK_LAYOUT(layout), entry, 265, 150);
	gtk_widget_set_size_request(entry, 80, 35);

	button=gtk_button_new_with_mnemonic("Valider");
	gtk_layout_put(GTK_LAYOUT(layout), button, 270, 250);
	gtk_widget_set_size_request(button, 160, 35);
	gtk_widget_set_tooltip_text(button, "Simple tip");

	g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(Menu_principal),entry);
	g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window0);

	gtk_widget_show_all (window0);
	gtk_window_set_resizable (GTK_WINDOW(window0), FALSE);
	gtk_widget_set_size_request (window0, L_FENETRE, H_FENETRE);
	gtk_main ();

	return 0;

}
/*
int main (int argc,char *argv[]){
  GtkWidget *window0,*hbox,*entry,*button,*table;

  srand(time(NULL));
  gtk_init (&argc, &argv);

  window0 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window0), "QCM drapeau-choix de la difficulté");
  gtk_window_set_default_size (GTK_WINDOW (window0), L_FENETRE, H_FENETRE);
  gtk_container_set_border_width (GTK_CONTAINER (window0), 5);
  gtk_window_set_position(GTK_WINDOW(window0), GTK_WIN_POS_CENTER_ALWAYS);

 hbox=gtk_box_new(GTK_ORIENTATION_HORIZONTAL,5);
  gtk_container_add(GTK_CONTAINER(window0),hbox);

  entry=gtk_entry_new();
  gtk_box_pack_start(GTK_BOX(hbox),entry,TRUE,TRUE,5);
  button=gtk_button_new_with_label("Valider");

  gtk_box_pack_start(GTK_BOX(hbox),button,FALSE,FALSE,0);

  g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(Choix_niveaux),entry);
  g_signal_connect_swapped(G_OBJECT(button), "clicked",G_CALLBACK( gtk_widget_destroy), window0);

  gtk_widget_show_all (window0);
  gtk_main ();

  return 0;
}

// const gchar* cur_value =gtk_entry_get_text (GTK_ENTRY (entry));
// g_snprintf(nom_dutilisatuer,50,"%s", gtk_entry_get_text(GTK_ENTRY(entry)));


xmlInitParser();
	LIBXML_TEST_VERSION


	  xmlDoc *doc = xmlParseFile(buf1);

	  xmlXPathContext *xpathCtx = xmlXPathNewContext( doc );
	  xmlXPathObject * xpathObj =xmlXPathEvalExpression( (xmlChar*)buf2, xpathCtx );
	  xmlNode *node = xpathObj->nodesetval->nodeTab[0];
	  //xmlSetProp( node, (xmlChar*)"age", (xmlChar*)"3" );
	  xmlNodeSetContent(node, "1");
	  xmlSaveFormatFileEnc( buf1, doc, "utf-8", 1 );
	  xmlXPathFreeObject( xpathObj );
	  xmlXPathFreeContext( xpathCtx );
	  xmlFreeDoc( doc );
	  xmlCleanupParser();*/
